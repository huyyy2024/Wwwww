package com.firebow.mixin;

import com.firebow.util.RotationUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Movement fix — điều chỉnh forward/sideways theo delta yaw đang pending.
 * Grim thấy movement vector nhất quán với rotation trong packet.
 */
@Environment(EnvType.CLIENT)
@Mixin(KeyboardInput.class)
public class KeyboardInputMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void firebow$fixInput(CallbackInfo ci) {
        if (!RotationUtil.hasPendingTarget()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        float[] rot = RotationUtil.getPendingRot(mc.player);
        if (rot == null) return;

        Input self = (Input)(Object) this;
        float forward  = self.movementForward;
        float sideways = self.movementSideways;
        if (forward == 0 && sideways == 0) return;

        // delta = yaw cần xoay thêm so với hướng player hiện tại
        float delta  = rot[0] - mc.player.getYaw();
        float yawRad = (float) Math.toRadians(delta);
        float cos    = (float) Math.cos(-yawRad);
        float sin    = (float) Math.sin(-yawRad);

        self.movementForward  = forward * cos - sideways * sin;
        self.movementSideways = forward * sin + sideways * cos;
    }
}
